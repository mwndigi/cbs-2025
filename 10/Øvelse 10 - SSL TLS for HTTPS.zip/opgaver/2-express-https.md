# Øvelse 2 – Express app med self-signed certifikater

Vi skal starte en Express app som kører på HTTPS

Kopier certifikater fra ´1-self-signed-https´ over til ´2-express-https´

Lav npm install og kør Express appen med ´npm start´ og gå til https://localhost:3000 (bemærk HTTPS) i en webbrowser

Klik på hængelåsen i Google Chrome for at inspicere certifikaterne

