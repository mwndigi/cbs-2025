// Simpel in-memory "database" for brugere
const users = [
  {
    username: "mikkel",
    email: "mwn.digi@cbs.dk",
    password: "digimikki",
  }
];

module.exports = users;